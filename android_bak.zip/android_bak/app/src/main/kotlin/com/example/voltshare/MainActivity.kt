package com.example.voltshare

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
